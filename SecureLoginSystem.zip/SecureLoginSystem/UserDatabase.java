import java.util.HashMap;

public class UserDatabase {
    private static HashMap<String, String> users = new HashMap<>();

    static {
        // Predefined users
        users.put("user@example.com", PasswordUtil.hashPassword("password123"));
    }

    public static boolean isValidUser(String email, String password) {
        if (!users.containsKey(email)) return false;
        return PasswordUtil.checkPassword(password, users.get(email));
    }
}