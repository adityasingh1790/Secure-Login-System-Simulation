import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SecureLogin extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JLabel statusLabel;
    private int attemptCount = 0;

    public SecureLogin() {
        setTitle("Secure Login System");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 2));
        emailField = new JTextField();
        passwordField = new JPasswordField();
        statusLabel = new JLabel(" ");

        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);

        JButton loginButton = new JButton("Login");
        panel.add(loginButton);
        panel.add(statusLabel);

        add(panel);

        loginButton.addActionListener(e -> {
            String email = emailField.getText().trim();
            String password = new String(passwordField.getPassword());

            if (email.isEmpty() || password.isEmpty()) {
                statusLabel.setText("Fields cannot be empty");
                return;
            }

            if (!email.matches("^[\\w-.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
                statusLabel.setText("Invalid email format");
                return;
            }

            if (attemptCount >= 3) {
                statusLabel.setText("Too many attempts!");
                loginButton.setEnabled(false);
                return;
            }

            if (UserDatabase.isValidUser(email, password)) {
                JOptionPane.showMessageDialog(this, "Login Successful!");
                statusLabel.setText("Welcome!");
            } else {
                attemptCount++;
                statusLabel.setText("Login failed (" + attemptCount + "/3)");
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SecureLogin login = new SecureLogin();
            login.setVisible(true);
        });
    }
}